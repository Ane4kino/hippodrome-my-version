package com.javarush.games.racer.road;

public enum RoadObjectType {
    CAR,
    BUS,
    TRUCK,
    SPORT_CAR,
    THORN,
    DRUNK_CAR
}