package com.javarush.games.racer;

public enum Direction {
    NONE, RIGHT, LEFT
}
